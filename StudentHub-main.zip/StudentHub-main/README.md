# StudentHub
The StudentHub is a desktop and mobile friendly launchpad that connects you with experts from around the college to help with assignment and tutoring and Easily navigate and keep track of their busy academic schedule.

This site connects people who need help with their assignments and assignment solvers. You simply post your question and multiple tutors will post their step by step explanations to your question
